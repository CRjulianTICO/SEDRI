<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
   <link rel="stylesheet" type="text/css" href="../public/css/cuenta.css"> 
</head>

<body>
  <div class="section"></div>
  <main>
    <center>
      

      
      <div class="section"></div>

      <div class="container">
        <div class="z-depth-1 grey lighten-4 row" style="display: inline-block; padding: 32px 48px 0px 48px; border: 1px solid #EEE;">

          <form class="col s12" method="post">
            <div class='row'>
              <div class='col s12'>
              	<h5 class="blue-text">Inicia sesión </h5>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s12'>
                	
<i class="material-icons prefix ">account_circle</i>
                <input class='validate' type='text' name='cedula' id='cedula' min="1000000" max="9999999" required />
                <label for='cedula'>Ingresa la Cédula</label>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s12'>
              	<i class="material-icons prefix">lock</i>
                <input class='validate' type='password' name='password' id='password' pattern=".{6,}" title="Debe tener 6-10 caracteres" required />
                <label for='password'>Digita la contraseña</label>
              </div>

              <label style='float: right;'>
								<a class='blue-text' href='recupera.html'><b>Olvido su contraseña </b> <i class="material-icons prefix bot">help_outline</i></a>
							</label>
            </div>

            <br />
            <center>
              <div class='row'>

                <button type='submit' name='btn_login' class='col s12 btn btn-large waves-effect blue'>Iniciar sesión <i class="material-icons prefix   center ">input</i></button>
              </div>
            </center>
          </form>
        </div>
      </div>
    </center>

    <div class="section"></div>
    <div class="section"></div>
  </main>

  
</body>

</html>